<template>
  <div id="app">
    <Topo/>
  </div>
</template>

<script>
import Topo from './components/Topo'

export default {
  name: 'app',
  components: {
    Topo
  }
}
</script>

<style>
body {
  margin: 0;
}
</style>
